# Live Exam System

A Django-based live examination system with role-based dashboards (Admin, Teacher, Student), basic exam authoring, question handling, and submissions with scoring. Frontend templates and static assets are organized under `frontend/`.

## Quick Start

1. Python 3.10+
2. Create virtualenv and install requirements:
   - Windows PowerShell
     - `python -m venv .venv`
     - `.venv\\Scripts\\Activate.ps1`
     - `pip install -r backend/requirements.txt`
3. Environment:
   - Copy `backend/.env` (already created with defaults) or set `SECRET_KEY`, `DEBUG`, `ALLOWED_HOSTS`.
4. Database and run:
   - `python backend/manage.py makemigrations`
   - `python backend/manage.py migrate`
   - `python backend/manage.py createsuperuser`
   - `python backend/manage.py runserver`

Open http://127.0.0.1:8000

## Notes
- Frontend templates: `frontend/templates/`
- Static files: `frontend/static/`
- Media uploads: `backend/media/`
- Custom user model with `role` (admin/teacher/student).
