from .models import User

def create_user(username: str, email: str, password: str, role: str = User.ROLE_STUDENT) -> User:
    user = User.objects.create_user(username=username, email=email, password=password)
    user.role = role
    user.save()
    return user
