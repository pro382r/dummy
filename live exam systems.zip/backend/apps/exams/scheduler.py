def schedule_exam(exam):
    return True
