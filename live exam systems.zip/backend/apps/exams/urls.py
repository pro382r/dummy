from django.urls import path
from . import views

urlpatterns = [
    path('', views.exam_list, name='exam_list'),
    path('create/', views.create_exam, name='create_exam'),
    path('<int:exam_id>/instructions/', views.exam_instructions, name='exam_instructions'),
    path('<int:exam_id>/add-question/', views.add_question, name='add_question'),
    path('<int:exam_id>/take/', views.take_exam, name='take_exam'),
]
