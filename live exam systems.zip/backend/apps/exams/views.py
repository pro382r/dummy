from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.forms import ModelForm
from django.contrib import messages
from apps.users.permissions import role_required
from .models import Exam
from apps.questions.models import Question
from apps.submissions.grader import grade_submission


class ExamForm(ModelForm):
    class Meta:
        model = Exam
        fields = ['title', 'description', 'duration_minutes', 'start_time', 'end_time', 'is_published']


class QuestionForm(ModelForm):
    class Meta:
        model = Question
        fields = ['text', 'option_a', 'option_b', 'option_c', 'option_d', 'correct_option', 'marks']


@login_required
@role_required('teacher')
def create_exam(request):
    if request.method == 'POST':
        form = ExamForm(request.POST)
        if form.is_valid():
            exam = form.save(commit=False)
            exam.created_by = request.user
            exam.save()
            messages.success(request, 'Exam created. You can now add questions.')
            return redirect('add_question', exam_id=exam.id)
    else:
        form = ExamForm()
    return render(request, 'exams/create_exam.html', {'form': form})


@login_required
def exam_list(request):
    if request.user.is_teacher():
        exams = Exam.objects.filter(created_by=request.user)
    else:
        exams = Exam.objects.filter(is_published=True)
    return render(request, 'exams/exam_list.html', {'exams': exams})


@login_required
@role_required('teacher')
def add_question(request, exam_id: int):
    exam = get_object_or_404(Exam, id=exam_id, created_by=request.user)
    if request.method == 'POST':
        form = QuestionForm(request.POST)
        if form.is_valid():
            q = form.save(commit=False)
            q.exam = exam
            q.save()
            messages.success(request, 'Question added.')
            if 'add_another' in request.POST:
                return redirect('add_question', exam_id=exam.id)
            return redirect('exam_list')
    else:
        form = QuestionForm()
    return render(request, 'exams/create_exam.html', {'form': form, 'exam': exam})


@login_required
def exam_instructions(request, exam_id: int):
    exam = get_object_or_404(Exam, id=exam_id)
    return render(request, 'exams/exam_instructions.html', {'exam': exam})


@login_required
@role_required('student')
def take_exam(request, exam_id: int):
    exam = get_object_or_404(Exam, id=exam_id, is_published=True)
    questions = Question.objects.filter(exam=exam)
    if request.method == 'POST':
        answers = {}
        for q in questions:
            answers[q.id] = request.POST.get(f'q-{q.id}', '')
        submission = grade_submission(exam, request.user, answers)
        return redirect('exam_result', submission_id=submission.id)
    return render(request, 'exams/take_exam.html', {'exam': exam, 'questions': questions})
