from .models import Exam

def publish_exam(exam: Exam):
    exam.is_published = True
    exam.save()
    return exam
