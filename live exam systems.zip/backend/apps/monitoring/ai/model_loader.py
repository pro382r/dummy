def load_model():
    return None
