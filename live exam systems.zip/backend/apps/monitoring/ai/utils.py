def preprocess(frame_bytes: bytes) -> bytes:
    return frame_bytes
