def detect_faces(frame_bytes: bytes) -> int:
    return 0
