import logging
logger = logging.getLogger(__name__)

def log(event: str, **kwargs):
    logger.info("%s | %s", event, kwargs)
