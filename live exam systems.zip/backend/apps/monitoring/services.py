from .models import ActivityLog

def log_activity(user, event: str, data: dict | None = None):
    return ActivityLog.objects.create(user=user if getattr(user, 'is_authenticated', False) else None, event=event, data=data or {})
