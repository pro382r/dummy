def make_report(data: dict) -> dict:
    return {'summary': data}
