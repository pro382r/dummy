from .models import Metric

def track(key: str, value: float = 1.0):
    return Metric.objects.create(key=key, value=value)
