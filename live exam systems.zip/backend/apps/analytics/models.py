from django.db import models


class Metric(models.Model):
    key = models.CharField(max_length=100)
    value = models.FloatField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [models.Index(fields=['key'])]
