from django.shortcuts import render


def index(request):
    return render(request, 'exams/exam_list.html')
