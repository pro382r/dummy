from .models import Question


def randomize_questions(exam):
    return Question.objects.filter(exam=exam).order_by('?')
