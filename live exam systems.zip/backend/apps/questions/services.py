def validate_question_data(data):
    return True
