def send_email(to_email: str, subject: str, body: str) -> bool:
    # Placeholder for SMTP integration
    return True
