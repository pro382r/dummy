from .models import Notification

def notify(user, subject: str, body: str) -> Notification:
    return Notification.objects.create(user=user, subject=subject, body=body)
