def summarize_submission(submission):
    return {
        'score': submission.score,
        'total': submission.answers.count(),
    }
