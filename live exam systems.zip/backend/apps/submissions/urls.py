from django.urls import path
from . import views

urlpatterns = [
    path('<int:submission_id>/', views.exam_result, name='exam_result'),
]
