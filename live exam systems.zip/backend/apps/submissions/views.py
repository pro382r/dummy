from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Submission


@login_required
def exam_result(request, submission_id: int):
    submission = get_object_or_404(Submission, id=submission_id, user=request.user)
    answers = submission.answers.select_related('question').all()
    return render(request, 'exams/exam_result.html', {'submission': submission, 'answers': answers})
