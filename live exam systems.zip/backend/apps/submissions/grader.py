from .models import Submission, Answer
from apps.questions.models import Question


def grade_submission(exam, user, answers: dict) -> Submission:
    submission = Submission.objects.create(exam=exam, user=user, score=0)
    score = 0
    q_map = {q.id: q for q in Question.objects.filter(exam=exam)}
    for qid, selected in answers.items():
        q = q_map.get(qid)
        if not q:
            continue
        is_correct = (selected == q.correct_option)
        if is_correct:
            score += q.marks
        Answer.objects.create(
            submission=submission,
            question=q,
            selected_option=selected or '',
            is_correct=is_correct,
        )
    submission.score = score
    submission.save()
    return submission
