def similarity(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    a_set, b_set = set(a.lower().split()), set(b.lower().split())
    if not a_set or not b_set:
        return 0.0
    return len(a_set & b_set) / len(a_set | b_set)
