def vectorize(text: str) -> dict:
    return {w: 1 for w in text.split()}
