from django.db import models


class PlagiarismCheck(models.Model):
    submission_id = models.IntegerField()
    score = models.FloatField(default=0.0)
    details = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
