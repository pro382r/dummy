from .similarity_engine import similarity

def check_similarity(text: str, corpus: list[str]) -> float:
    return max((similarity(text, c) for c in corpus), default=0.0)
