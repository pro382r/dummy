class Roles:
    ADMIN = 'admin'
    TEACHER = 'teacher'
    STUDENT = 'student'

    ALL = (ADMIN, TEACHER, STUDENT)
