from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.exceptions import PermissionDenied


class RoleRequiredMixin(LoginRequiredMixin):
    roles = None

    def dispatch(self, request, *args, **kwargs):
        user = request.user
        if user.is_superuser or user.is_staff:
            return super().dispatch(request, *args, **kwargs)
        if self.roles and getattr(user, 'role', None) not in self.roles:
            raise PermissionDenied
        return super().dispatch(request, *args, **kwargs)
