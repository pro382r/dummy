def non_empty(value: str) -> bool:
    return bool(value and value.strip())
