def clamp(n, min_value, max_value):
    return max(min(n, max_value), min_value)
