from functools import wraps
from django.http import HttpResponseForbidden


def role_required(*roles):
    def decorator(view_func):
        @wraps(view_func)
        def _wrapped(request, *args, **kwargs):
            user = request.user
            if not user.is_authenticated:
                from django.contrib.auth.views import redirect_to_login
                return redirect_to_login(next=request.get_full_path())
            if user.is_superuser or user.is_staff:
                return view_func(request, *args, **kwargs)
            if roles and getattr(user, 'role', None) not in roles:
                return HttpResponseForbidden('Forbidden')
            return view_func(request, *args, **kwargs)
        return _wrapped
    return decorator
