Frontend for Live Exam System.

- Templates in templates/
- Static assets in static/
- Components are included in base.html via Django template includes.
