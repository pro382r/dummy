(async function(){
  async function startCamera(videoId='examCamera'){
    try{
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      const video = document.getElementById(videoId);
      if(video){
        video.srcObject = stream;
        await video.play();
      }
      return stream;
    }catch(e){
      console.warn('Camera permission denied or not available', e);
      return null;
    }
  }
  window.startExamCamera = startCamera;
})();
