(function(){
  window.checkPlagiarism = function(text){
    console.log('Plagiarism check requested for length', (text||'').length);
  };
})();
