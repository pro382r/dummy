(function(){
  let opened = false; const threshold = 160;
  const detect = () => {
    const w = window.outerWidth - window.innerWidth;
    const h = window.outerHeight - window.innerHeight;
    const isOpen = (w > threshold) || (h > threshold);
    if (isOpen !== opened) {
      opened = isOpen;
      window.dispatchEvent(new CustomEvent('devtools-change', { detail: { opened } }));
    }
  };
  setInterval(detect, 1000);
})();
