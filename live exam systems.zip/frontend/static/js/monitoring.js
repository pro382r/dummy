(function(){
  window.addEventListener('tab-visibility', e => {
    console.log('Tab visibility changed', e.detail);
  });
  window.addEventListener('devtools-change', e => {
    console.warn('Devtools state', e.detail);
  });
})();
