(function(){
  console.log('Analytics initialized');
})();
