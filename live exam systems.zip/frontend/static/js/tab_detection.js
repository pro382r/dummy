(function(){
  let hiddenCount = 0;
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) hiddenCount++;
    window.dispatchEvent(new CustomEvent('tab-visibility', { detail: { hidden: document.hidden, hiddenCount } }));
  });
})();
